
$(function() {
    console.log( "ready!" );
	$('#volUp').click(function(){
		$.post("/m", { comando: "mas" });
	});
	$('#volDown').click(function(){
		$.post("/m", { comando: "menos" });
	});
});
